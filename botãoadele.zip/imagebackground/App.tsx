import React from 'react';
import {ImageBackground, StyleSheet, Text, View } from 'react-native';
import { Card } from 'react-native-paper';

const image = {uri: 'https://lorena.r7.com/public/assets/img/postagens/post_8385.jpg'};
import AssetExample from './assets/components/AssetExample';
import Untitledfile from './assets/components/Untitledfile';

const App = () => (
  <View style={styles.container}>
    <ImageBackground source={image} resizeMode="cover" style={styles.image}>
<Untitledfile />
      <Text style={styles.text}>Olá!</Text>
   <Card> 
    <AssetExample /> 
   </Card>
    </ImageBackground>
  </View>
);

const styles = StyleSheet.create({
  container: {
    flex: 1,},
  image: {
    flex: 1,
    justifyContent: 'center',
  },
  text: {
    color: 'white',
    fontSize: 42,
    lineHeight: 84,
    fontWeight: 'bold',
    textAlign: 'center',
    backgroundColor: '#000000c0',
  },
});

export default App;